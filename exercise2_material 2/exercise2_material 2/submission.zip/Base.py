# Layers/Base.py

class BaseLayer:
    def __init__(self):
        self.trainable = False
        self.weights = None
